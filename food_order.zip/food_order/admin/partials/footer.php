<div class="footer">
            <div class="wrapper">
                <p class="text-center">2024 All rights reserved, Quick Bite. Developed By - <a href="#"> Shahriar Sajib</a></p>
            </div>
        </div>

    </body>
</html>